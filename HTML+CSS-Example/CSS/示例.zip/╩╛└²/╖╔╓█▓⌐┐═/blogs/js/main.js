/**
 * Created by chen on 2016/11/22.
 */
window.onload=function () {
    var iB=document.getElementsByClassName("search");//获取搜索图片
    var inp=document.getElementById("in1");//input:text
    var fo=document.getElementsByClassName("searchF");//搜索条
    var top1=document.getElementsByClassName("Top");//回到顶部
    var bt=document.getElementsByClassName("bt");//按钮盒子
    var sp=document.getElementsByClassName("sp");//滚动图片上的按钮
    var sD1b=document.getElementsByClassName("sD1b");//左右滚动3d盒子
    var sD1b2=document.getElementsByClassName("sD1b2");//上下滚动3d盒子
    var sD1a=document.getElementsByClassName("i1");//景深左边图片
    var aP=document.getElementsByClassName("lj");//滚动图片文字
    // var aA=document.getElementsByTagName("a");
    var img1='url(./img/navSearch2.jpg)';
    var img2='url(./img/navSearch.jpg)';
    var a="hidden";
    var time,num=0,xz,sj,yc;
    // 搜索栏是否显示可见
    iB[0].onclick=function () {
        if (a=="hidden"){
             vis();
            a="visible";
        }else {
            hid();
            a="hidden";
        }

    }
    ini(); // 初始图片边框
    pd(); // 焦点移出页面停止定时器
    jd(); // 页面获得焦点开启定时器

    // 滚动图片左点击按钮
    sp[0].onclick=function () {
        sD1b[0].style.transition="none";
        sD1b2[0].style.transition="none";
        num-=90;
        yc3();
    }
    // 滚动图片暂停按钮
    sp[1].onclick=function () {
        clearInterval(xz);
        sp[1].style.display="none";
        sp[3].style.display="block";
    }
    // 滚动图片右点击按钮
    sp[2].onclick=function () {
        sD1b[0].style.transition="none";
        sD1b2[0].style.transition="none";
        num+=90;
        yc3();
    }
    // 滚动图片开始按钮
    sp[3].onclick=function () {
        sp[3].style.display="none";
        sp[1].style.display="block";
        yc3();
    }
    // 景深左边图片1
    sD1a[0].onclick=function () {
        sD1b[0].style.transition="none";
        sD1b2[0].style.transition="none";
        num=0;
        yc3();
    }
    // 景深左边图片2
    sD1a[1].onclick=function () {
        sD1b[0].style.transition="none";
        sD1b2[0].style.transition="none";
        num=90;
        yc3();
    }
    // 景深左边图片3
    sD1a[2].onclick=function () {
        sD1b[0].style.transition="none";
        sD1b2[0].style.transition="none";
        num=180;
        yc3();
    }
    // 景深左边图片4
    sD1a[3].onclick=function () {
        sD1b[0].style.transition="none";
        sD1b2[0].style.transition="none";
        num=270;
        yc3();
    }
    // 搜索栏placeholder文字显示
    inp.onblur=function () {
        inp.setAttribute('placeholder','search...');
    }

    // top1[0].onclick=function () {
    //     topFn();
    // }

    // 滚动图片悬浮显示按钮
    bt[0].onmouseover=function () {
        for(var i=0;i<sp.length;i++){
            sp[i].style.visibility="visible";
        }
    }
    // 滚动图片移出隐藏按钮
    bt[0].onmouseout=function () {
        for(var i=0;i<sp.length;i++){
            sp[i].style.visibility="hidden";
        }
    }
    // 搜索栏可显示
    function vis() {
        fo[0].style.visibility="visible";
        inp.focus();
        inp.setAttribute('placeholder','');
        iB[0].style.backgroundImage=img1;
    }
    // 初始图片边框
    function ini() {
        if (num==0){
            sD1a[0].style.borderColor="rgb(188,224,221)";
            aP[0].style.visibility="visible";
            aP[0].style.left="20px";
            var yc5=setTimeout(function () {
                for(var j=0;j<aP.length;j++){
                    aP[j].style.transition="none";
                    aP[j].style.visibility="hidden";
                    aP[j].style.left="-500px";
                }
            },4000);
            ty();  // 滚动图片移动和滚动盒子切换隐藏
        }
    }
    // 搜索栏不可显示
    function hid() {
        fo[0].style.visibility="hidden";
        iB[0].style.backgroundImage=img2;
    }
    // 清除定时器，重新开启定时器
    function yc3() {
        clearInterval(xz);
        sD1b[0].style.transform="rotateY("+num+"deg)";
        sD1b2[0].style.transform="rotateX("+num+"deg)";
        var dd=setTimeout(function () {
            sD1b[0].style.transition="2s";
            sD1b2[0].style.transition="2s";
            ty();
        },100)
    }
    // 滚动图片移动和滚动盒子切换隐藏
    function ty() {
         xz=setInterval(function () {
             var ran=Math.floor(Math.random()*10);
             if(ran<=5){
                 num+=90;
             }else{
                 num-=90;
             }
            sD1b[0].style.transform="rotateY("+num+"deg)";
            sD1b2[0].style.transform="rotateX("+num+"deg)";
             sj=Math.random()*10;
             bor(); // 景深左边图片边框颜色
             yc=setTimeout(function () {
                 if(sj<=5){
                     sD1b[0].style.visibility="hidden";
                     sD1b2[0].style.visibility="visible";
                 }else {
                     sD1b2[0].style.visibility="hidden";
                     sD1b[0].style.visibility="visible";
                 }
                 //滚动图片文字
                 var yc4=setTimeout(function () {
                     for(var j=0;j<aP.length;j++){
                         aP[j].style.transition="none";
                         aP[j].style.visibility="hidden";
                         aP[j].style.left="-250px";
                     }
                 },1800)
             },2200);
        },4400)
    }
    // 景深左边图片边框颜色和文字
    function bor() {
        if(num==0||num==360||num==-360||num==720||num==-720||num==1080||num==-1080||num==1440||num==-1440){
            sD1a[0].style.borderColor="rgb(188,224,221)";
            aP[0].style.transition="0.2s linear";
            aP[0].style.visibility="visible";
            aP[0].style.left="20px";
        }else {
            sD1a[0].style.borderColor="#fff";
        }
        if(num==90||num==-270||num==450||num==-630||num==810||num==-990||num==1170||num==-1350||num==1530||num==-1710){
            sD1a[1].style.borderColor="rgb(188,224,221)";
            aP[1].style.transition="0.2s linear";
            aP[1].style.visibility="visible";
            aP[1].style.left="20px";
        }else {
            sD1a[1].style.borderColor="#fff";
        }
        if(num==180||num==-180||num==-540||num==540||num==-900||num==900||num==-1260||num==1260||num==-1620||num==1620){
            sD1a[2].style.borderColor="rgb(188,224,221)";
            aP[2].style.transition="0.2s linear";
            aP[2].style.visibility="visible";
            aP[2].style.left="20px";
        }else {
            sD1a[2].style.borderColor="#fff";
        }
        if(num==270||num==-90||num==630||num==-450||num==990||num==-810||num==1350||num==-1170||num==1710||num==-1530){
            sD1a[3].style.borderColor="rgb(188,224,221)";
            aP[3].style.transition="0.2s linear";
            aP[3].style.visibility="visible";
            aP[3].style.left="20px";
        }else {
            sD1a[3].style.borderColor="#fff";
        }
    }
    // 焦点移出页面停止定时器
    function pd() {
        window.onblur=function () {
            clearInterval(xz);
        }
    }
    // 页面获得焦点开启定时器
    function jd() {
        window.onfocus=function () {
            yc3();
        }
    }
}