//Tells user to login before voting
function regclose() {
var regobj = document.getElementById('regbox');
regobj.style.display = "none";
}
function regboxopen() {
var regobj = document.getElementById('regbox');
regobj.style.display = "block";
}