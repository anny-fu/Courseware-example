setTimeout(function(){
        $("video").on("play", function() {
        var $video = $("video");
        var video_leng = $video.length;
        /*添加父级div,为了保证获取的index只有video标签的*/
        var thisIndex = $(this).index();
        for(var i = 0; i < video_leng; i++) {
            if(i === thisIndex) {
                continue;
            } else {
                 $video.eq(i)[0].pause();
            }
        }
        var $audioBox = $(".audio-box");
        var audioBox_leng = $audioBox.length;
        for(var j = 0; j < audioBox_leng; j++) {
            if($audioBox.eq(j).children("span").is(".playing")) {
                $audioBox.eq(j).children("span").trigger("click");
            } else {
                continue;
            }
        }
    });
    // var audio = document.getElementsByTagName('audio');
    // var video = document.getElementsByTagName('video');
    // var media = [];
    // var l = audio.length + video.length;
    // for(let i = 0,len = audio.length;i < len;i++){
    //     media.push(audio[i]);
    // }
    // for(let i = 0,len = video.length;i < len;i++){
    //     media.push(video[i]);
    // }
    // if(l != 0){
    //     judgeMedia(media,l);
    // }
},1000)
//判断音频资源函数，参数音频元素与音频长度
function judgeMedia(e, l) {

    //定义一个空数组
    /*var arr = [];
    var _loop = function _loop(i, len) {
        e[i].index = i;
        //监听视频,音频播放
        e[i].addEventListener('play', function () {
            arr.push(i);
            if (arr.length > 1) {
                for (var j = 0, _len2 = arr.length; j < _len2; j++) {
                    //暂停
                    e[arr[j]].pause();
                    if (i <= e.length) {
                        //播放
                        e[this.index].play();
                    }
                }
            }
        });
        //监听视频,音频暂停事件
        e[i].addEventListener('pause', function () {
            arr.pop(i);
            if (arr.length > 1) {
                for (var j = 0, _len3 = arr.length; j < _len3; j++) {
                    //播放
                    e[j].play();
                }
            } else if (arr.length != 1) {
                for (var _j = 0, _len4 = arr.length; _j < _len4; _j++) {
                    //暂停
                    e[_j].pause();
                }
            }
        });
    };
    for (var i = 0, len = e.length; i < len; i++) {
        _loop(i, len);
    }*/
}