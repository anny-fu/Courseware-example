module.exports = {
  // some nuxt config...
  plugins: [
    { src: '~plugins/nuxt-video-player-plugin.js', ssr: false }
  ],
  // some nuxt config...
  css: [
    'video.js/dist/video-js.css'
  ],
  // some nuxt config...
}
