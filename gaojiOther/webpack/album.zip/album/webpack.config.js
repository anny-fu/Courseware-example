/**
 * 功能：webpack的配置文件
 * 日期：2017/11/17
 **/
// 请求路径设置的node内置模块
const path = require('path');

module.exports = {
	// 设置环境路径为项目根目录
	//context: __dirname + '/js',
	// 入口
	entry: './js/entry.js',
	// 出口
	output: {
		// 定义输出路径
		path: path.resolve(__dirname, './js'),
		// 定义输出名称
		filename: 'bundle.js'
	}
};

