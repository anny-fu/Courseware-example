/**
 * 功能：首页功能
 * 日期：2017/11/17
 **/
var common = require("./common");

$("figure > div > img").on("click", function () {
	common.fullScreen(this);
});
