/**
 * 功能：入口文件
 * 日期：2017/11/17
 **/

require("./common");
require("./index");