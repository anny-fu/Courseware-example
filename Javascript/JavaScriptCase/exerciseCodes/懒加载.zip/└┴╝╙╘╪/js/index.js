/**
 * 功能：图片懒加载
 * 开发人员：Tom.Anny
 * 日期：2018/4/3
 */
// 图片资源数组
var  imgArr = ["img/1.jpg","img/2.jpg","img/3.jpg","img/4.jpg","img/5.jpg","img/6.jpg","img/7.jpg","img/8.jpg","img/9.jpg","img/10.jpg","img/11.jpg","img/12.jpg"];